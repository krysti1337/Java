export declare const icons: {
    crosshair: import("lit-html").TemplateResult<2>;
    square: import("lit-html").TemplateResult<2>;
    font: import("lit-html").TemplateResult<2>;
    undo: import("lit-html").TemplateResult<2>;
    redo: import("lit-html").TemplateResult<2>;
    cross: import("lit-html").TemplateResult<2>;
};
