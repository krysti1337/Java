package com.example.ui;

import com.example.core.ExpressionEvaluator;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.component.orderedlayout.FlexComponent;

@Route("")
public class CalculatorView extends VerticalLayout {
    public CalculatorView() {
        setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.CENTER);
        TextField input = new TextField("INTRODUCETI EXPRESIA");
        Button resultButton = new Button("REZULTAT");
        Span result = new Span();

        resultButton.addClickListener(e -> {
            String expression = input.getValue();
            int output = ExpressionEvaluator.evaluate(expression);
            result.setText("Result: " + output);
        });

        add(input, resultButton, result);
    }
}
