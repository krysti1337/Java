package com.example.core;

import java.util.Stack;

public class ExpressionEvaluator {

    /**
      Metoda principala care evalueaza o expresie aritmetica (ex: "3 + (2 * 4)").
      Folosim doua stack-uri:
      - Stack<Integer> values → tine numerele (valori intermediare sau finale)
      - Stack<Character> ops → tine operatorii (+, -, *, /) si parantezele
      Logica de functionare:
      - Se parcurge expresia caracter cu caracter.
      - Cand gasim un numar, il construim si il adaugam in stack `values`.
      - Cand gasim un operator sau o paranteza, il procesam si il adaugam in `ops`.
      - Daca intalnim o paranteza inchisa `)`, rezolvam toate operatiile pana la paranteza deschisa `(`.
      - Dupa ce se parcurge intreaga expresie, rezolvam tot ce mai e in stive.
      Returneaza rezultatul expresiei evaluate.
     */
    public static int evaluate(String expression) {
        Stack<Integer> values = new Stack<>();
        Stack<Character> operator = new Stack<>();

        int i = 0;
        while (i < expression.length()) {
            char character = expression.charAt(i);

            // Ignora spatiile goale (ex: "3 + 4")
            if (Character.isWhitespace(character)) {
                i++;
                continue;
            }

            // Daca caracterul este cifra, formam numarul complet (poate avea mai multe cifre)
            if (Character.isDigit(character)) {
                int num = 0;
                while (i < expression.length() && Character.isDigit(expression.charAt(i))) {
                    num = num * 10 + (expression.charAt(i) - '0');
                    i++;
                }
                values.push(num); // Adaugam numarul in stack
                continue; // Trecem la urmatorul caracter
            }

            // Daca gasim o paranteza deschisa, o punem in stack de operatori
            if (character == '(') {
                operator.push(character);
            }
            // Daca gasim o paranteza inchisa, procesam tot intre ele
            else if (character == ')') {
                while (!operator.isEmpty() && operator.peek() != '(') {
                    int rezultat = applyOp(operator.pop(), values.pop(), values.pop());
                    values.push(rezultat);
                }
                // Scoatem '(' din stack (nu il folosim, doar inchidem blocul)
                if (!operator.isEmpty() && operator.peek() == '(') {
                    operator.pop();
                } else {
                    throw new IllegalArgumentException("Paranteza deschisa lipsa");
                }
            }
            // Daca gasim un operator (+, -, *, /)
            else if (isOperator(character)) {
                // Verificam daca operatorul precedent are prioritate mai mare sau egala
                // si facem acea operatie inainte
                while (!operator.isEmpty() && precedence(character) <= precedence(operator.peek())) {
                    int rezultat = applyOp(operator.pop(), values.pop(), values.pop());
                    values.push(rezultat);
                }
                operator.push(character); // Adaugam noul operator
            }

            i++;
        }

        // Dupa ce terminam parcurgerea expresiei, aplicam toate operatiile ramase
        while (!operator.isEmpty()) {
            int rezultat = applyOp(operator.pop(), values.pop(), values.pop());
            values.push(rezultat);
        }

        // Daca avem un singur element ramas in stack de valori, acesta este rezultatul
        if (values.size() != 1) {
            throw new IllegalArgumentException("Expresie invalida");
        }
        return values.pop();
    }

    /**
     * Verifica daca un caracter este un operator care accepta.
     * Accepta doar: +, -, *, /
     */
    private static boolean isOperator(char op) {
        return op == '+' || op == '-' || op == '*' || op == '/';
    }

    /**
     * Returneaza prioritatea unui operator.
     * - + si - → prioritate 1
     * - * si / → prioritate 2
     */
    private static int precedence(char op) {
        if (op == '+' || op == '-') return 1;
        if (op == '*' || op == '/') return 2;
        return 0;
    }

    /**
     * Aplica o operatie intre doua numere (a si b).
     * IMPORTANT: `b` este scos primul din stack, deci este operandul din dreapta.
     * Exemplu:
     * - pentru 3 - 2: a = 3, b = 2 → returneaza 1
     * - pentru 4 / 2: a = 4, b = 2 → returneaza 2
     * Arunca exceptie daca se incearca impartirea la 0.
     */
    private static int applyOp(char op, int b, int a) {
        switch (op) {
            case '+': return a + b;
            case '-': return a - b;
            case '*': return a * b;
            case '/':
                if (b == 0) throw new ArithmeticException("Impartire la zero");
                return a / b;
        }
        throw new IllegalArgumentException("Operator necunoscut: " + op);
    }
}
    // Test
//    public static void main(String[] args) {
//        String expr = "(11 + 18) * 20 - 2";
//        try {
//            int result = evaluate(expr);
//            System.out.println("Rezultat: " + result); // ar trebui să afișeze 578
//        } catch (Exception e) {
//            System.out.println("Eroare: " + e.getMessage());
//        }
//    }
